import sqlite3
Book=sqlite3.connect('Bookdb.db')
curbook=Book.cursor()
price=0
while True:
    t=input("Enter name of the book:")
    if t=="":
        break
    t1=(t,)
    curbook.execute('SELECT * FROM BOOKINFO WHERE TITLE=?',t1)
    result=curbook.fetchall()
    if result==[]:
        print("no book") 
    else:
        for record in result:
            print (record)
            noofcopy=int(input("Enter number of copies:"))
            curbook.execute('SELECT PRICE FROM BOOKINFO WHERE TITLE=?',t1)
            p=curbook.fetchone()
            price=price+p[0]*noofcopy
            add=input("Add more books y/n:")
            if add=='n':
                print("amount:",price)
                
        break

Book.close()


